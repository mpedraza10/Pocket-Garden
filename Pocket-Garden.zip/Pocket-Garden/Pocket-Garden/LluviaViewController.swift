//
//  LluviaViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 08/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class LluviaViewController: UIViewController {

    @IBOutlet var lluviaImg: UIImageView!
    @IBOutlet var lluviaLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let dataBaseRef = Database.database().reference()
        dataBaseRef.child("Ana").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? String else {
                return
            }
            
            lluviaLbl.text = value
            if value == "No está lloviendo. El techo está abierto" {
                lluviaImg.image = UIImage(named: "nube")
            } else {
                lluviaImg.image = UIImage(named: "lluvia")
            }
            
        })
    }
}
