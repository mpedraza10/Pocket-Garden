//
//  HistorialPuertaViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 11/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class HistorialPuertaViewController: UIViewController {

    
    @IBOutlet var historialTabla: UITableView!
    @IBOutlet var clearBtn: UIButton!
    
    var dates = [String]() {
        didSet {
            self.historialTabla.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        historialTabla.dataSource = self
        observeHistory()
        
        
    }
    
    func observeHistory() {
        // Creamos referencia y leemos valor de la base de datos
        let dataBaseRef = Database.database().reference().child("fechaHoraPuertaAbierta").queryOrderedByKey()
        
        dataBaseRef.observe(.value) { [self] snapshot in
            let enumerator = snapshot.children
            while let rest = enumerator.nextObject() as? DataSnapshot {
                if !dates.contains(rest.value as!String) {
                    dates.append(rest.value as! String)
                }
            }
        }
    }
    
    @IBAction func clearBtn(_ sender: Any) {
        // Creamo referencia a elemento a borrar
        let dataBaseRef = Database.database().reference().child("fechaHoraPuertaAbierta")
        
        // Delete the file
        dataBaseRef.removeValue() { error, _ in
            // Alerta para puerta
            let alertaBorrado = UIAlertController(title: "Datos eliminados", message: "Los datos han sido borrados", preferredStyle: .alert)
            let okButton = UIAlertAction(title: "Ok", style: .default)
            alertaBorrado.addAction(okButton)

            self.present(alertaBorrado,animated: true)
        }
        
        dates.removeAll();
        historialTabla.reloadData();


    }
    
}

extension HistorialPuertaViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dates.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = historialTabla.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = "La puerta se abrió el: \(dates[indexPath.row])"
        return cell
    }
}

