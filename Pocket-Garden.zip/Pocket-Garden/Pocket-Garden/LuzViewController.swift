//
//  LuzViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 08/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class LuzViewController: UIViewController {

    @IBOutlet var luzImage: UIImageView!
    @IBOutlet var luzLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Creamos referencia y leemos valor de la base de datos
        let dataBaseRef = Database.database().reference()
        dataBaseRef.child("Cruz").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? Double else {
                return
            }
                
            // Desplegamos el valor en nuestra aplicacion
            if value < 100.00 {
                luzImage.image = UIImage(named: "ledGrande")
                luzLbl.text = "No hay suficiente luz solar, el led esta encendido"
            } else {
                luzImage.image = UIImage(named: "solGrande")
                luzLbl.text = "Hay suficiente luz solar, el led esta apagado"
            }
        })
    }

}
