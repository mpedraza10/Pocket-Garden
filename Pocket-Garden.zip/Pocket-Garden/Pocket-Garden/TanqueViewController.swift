//
//  TanqueViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 29/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class TanqueViewController: UIViewController {

    @IBOutlet var tanqueImg: UIImageView!
    @IBOutlet var tanqueLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Creamos referencia y leemos valor de la base de datos
        let dataBaseRef = Database.database().reference()
        dataBaseRef.child("Cruz2").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? Int else {
                return
            }
                
            // Desplegamos el valor en nuestra aplicacion
            if value == 0 {
                tanqueImg.image = UIImage(named: "tanqueVacio")
                tanqueLbl.text = "No hay agua en el tanque"
            } else {
                tanqueImg.image = UIImage(named: "tanqueLleno")
                tanqueLbl.text = "Hay suficiente agua en el tanque"
            }
        })
    }

}
