//
//  puertaViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 08/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class puertaViewController: UIViewController {
    
    @IBOutlet var puertaLbl: UILabel!
    @IBOutlet var puertaImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Creamos referencia y leemos valor de la base de datos
        let dataBaseRef = Database.database().reference()
        dataBaseRef.child("Pedraza").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? String else {
                return
            }
                
            // Desplegamos el valor en nuestra aplicacion
            puertaLbl.text = value
            if value == "La puerta esta cerrada" {
                puertaImg.image = UIImage(named: "puertaCerrada")
            } else {
                puertaImg.image = UIImage(named: "puertaAbierta")
            }
        })
        
    }
}


