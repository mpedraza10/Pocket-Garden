//
//  RiegoViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 08/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class RiegoViewController: UIViewController {

    @IBOutlet var riegoLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let dataBaseRef = Database.database().reference()
        dataBaseRef.child("Pau").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? String else {
                return
            }
            
            riegoLbl.text = value;
        })
    }
    
}
