//
//  temperaturaViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 08/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class temperaturaViewController: UIViewController {

    @IBOutlet var tempLbl: UILabel!
    @IBOutlet var ventiladorLbl: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        let dataBaseRef = Database.database().reference()
        dataBaseRef.child("Panchito").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? Double else {
                return
            }
            
            tempLbl.text = String(value) + "°C";
            if value >= 25.0 {
                ventiladorLbl.text = "Ventilador encendido"
            } else {
                ventiladorLbl.text = "Ventilador apagado"
            }
        })
    }
}
