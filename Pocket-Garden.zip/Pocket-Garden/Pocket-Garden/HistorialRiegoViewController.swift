//
//  HistorialRiegoViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 13/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class HistorialRiegoViewController: UIViewController {

    @IBOutlet var historialRiegoTabla: UITableView!
    @IBOutlet var clearBtn: UIButton!
    
    var riegos = [String]() {
        didSet {
            self.historialRiegoTabla.reloadData()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        historialRiegoTabla.dataSource = self
        observeHistory()
        
    }
    
    func observeHistory() {
        // Creamos referencia y leemos valor de la base de datos
        let dataBaseRef = Database.database().reference().child("fechaHoraSueloHumedo").queryOrderedByKey()
        
        dataBaseRef.observe(.value) { [self] snapshot in
            let enumerator = snapshot.children
            while let rest = enumerator.nextObject() as? DataSnapshot {
                if !riegos.contains(rest.value as!String) {
                    riegos.append(rest.value as! String)
                }
            }
        }
    }
    
    @IBAction func clearBtn(_ sender: Any) {
        // Creamo referencia a elemento a borrar
        let dataBaseRef = Database.database().reference().child("fechaHoraSueloHumedo")
        
        // Delete the file
        dataBaseRef.removeValue() { error, _ in
            // Alerta para puerta
            let alertaBorrado = UIAlertController(title: "Datos eliminados", message: "Los datos han sido borrados", preferredStyle: .alert)
            let okButton = UIAlertAction(title: "Ok", style: .default)
            alertaBorrado.addAction(okButton)

            self.present(alertaBorrado,animated: true)
        }
        
        riegos.removeAll();
        historialRiegoTabla.reloadData();
    }
    
}

extension HistorialRiegoViewController: UITableViewDataSource {
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return riegos.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = historialRiegoTabla.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        
        cell.textLabel?.text = "Se regaron las plantas el: \(riegos[indexPath.row])"
        return cell
    }
}
