//
//  ViewController.swift
//  Pocket-Garden
//
//  Created by Miguel Pedraza on 08/11/21.
//

import UIKit
import Firebase
import FirebaseDatabase

class ViewController: UIViewController {

    @IBOutlet var trailing: NSLayoutConstraint!
    @IBOutlet var leading: NSLayoutConstraint!
    
    var menuOut = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Creamos referencia de base de datos
        let dataBaseRef = Database.database().reference()
        
        // Leemos valor de puerta para crear alerta
        dataBaseRef.child("Pedraza").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? String else {
                return
            }
        
            if value != "La puerta esta cerrada" {
                // Alerta para puerta
                let alertaPuerta = UIAlertController(title: "¡La puerta ha sido abierta!", message: "Se detectado que alguien abrió la puerta", preferredStyle: .alert)
                let okButton = UIAlertAction(title: "Ok", style: .default)
                alertaPuerta.addAction(okButton)

                present(alertaPuerta,animated: true)
            }
        })
        
        // Leemos valor de lluvia para crear alerta si esta lloviendo o no
        dataBaseRef.child("Ana").observe(.value, with: { [self] snapshot in
            guard let value = snapshot.value as? String else {
                return
            }
            
            if value != "No está lloviendo. El techo está abierto" {
                // Alerta para puerta
                let alertaTecho = UIAlertController(title: "¡Empezó a llover!", message: "El techo se ha cerrado", preferredStyle: .alert)
                let okButton = UIAlertAction(title: "Ok", style: .default)
                alertaTecho.addAction(okButton)

                present(alertaTecho,animated: true)
            }
        })

    }

    @IBAction func menuTapped(_ sender: Any) {
        if menuOut == false {
            leading.constant = 150;
            trailing.constant = -150;
            menuOut = true;
        } else {
            leading.constant = 0;
            trailing.constant = 0;
            menuOut = false;
        }
        
        UIView.animate(withDuration: 0.2, delay: 0.0, options: .curveEaseIn, animations: {
            self.view.layoutIfNeeded()
        }) 
    }
}


